let currentIndex = 0;

function rotateImages() {
  const carouselImages = document.querySelector('.carousel-images');
  const totalImages = carouselImages.children.length;

  // Update the transform to show the next image
  currentIndex = (currentIndex + 1) % totalImages;
  carouselImages.style.transform = `translateX(-${currentIndex * 100}%)`;
}

// Change images every 5 seconds
setInterval(rotateImages, 5000);

// Select the necessary elements
const carouselImages = document.querySelectorAll('.carousel-images img');
const dotsContainer = document.querySelector('.dots-container');

// Create dots based on the number of images
carouselImages.forEach((_, index) => {
  const dot = document.createElement('span');
  dot.className = 'dot'; // Add base class
  if (index === 0) dot.classList.add('active'); // Set first dot as active
  dotsContainer.appendChild(dot);
});

// Function to update active dot
function updateActiveDot(index) {
  const dots = dotsContainer.querySelectorAll('.dot');
  dots.forEach((dot, i) => {
    dot.classList.toggle('active', i === index); // Only the current dot gets the active class
  });
}

// Automatic carousel sliding logic
function slideShow() {
  currentIndex = (currentIndex + 1) % carouselImages.length; // Loop through slides
  const offset = currentIndex * -100; // Calculate the new position
  document.querySelector('.carousel-images').style.transform = `translateX(${offset}%)`;
  updateActiveDot(currentIndex); // Update the active dot
}

// Start the slideshow
setInterval(slideShow, 5000);
